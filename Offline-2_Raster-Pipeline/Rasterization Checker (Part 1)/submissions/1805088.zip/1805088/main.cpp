#include <bits/stdc++.h>
#include "Matrix.h"

using namespace std;

#define SCENE_FILE "scene.txt"
#define STAGE1_FILE "stage1.txt"
#define STAGE2_FILE "stage2.txt"
#define STAGE3_FILE "stage3.txt"

int main()
{
    ifstream scene, config;
    ofstream stage;

    double eyeX, eyeY, eyeZ;
    double lookX, lookY, lookZ;
    double upX, upY, upZ;
    double fovY, aspectRatio, near, far;

    int noOfTriangles = 0;

    // Stage 1 Start
    // -------------
    scene.open(SCENE_FILE);
    stage.open(STAGE1_FILE);

    scene >> eyeX >> eyeY >> eyeZ;
    scene >> lookX >> lookY >> lookZ;
    scene >> upX >> upY >> upZ;
    scene >> fovY >> aspectRatio >> near >> far;

    stack<Matrix> st;
    Matrix identity = Matrix::identityMatrix();
    st.push(identity);

    string cmd;
    while (true)
    {
        scene >> cmd;
        // cout << cmd << endl;

        if (cmd == "triangle")
        {
            PointVector point1, point2, point3;
            scene >> point1.x >> point1.y >> point1.z;
            scene >> point2.x >> point2.y >> point2.z;
            scene >> point3.x >> point3.y >> point3.z;

            point1 = st.top() * point1;
            point2 = st.top() * point2;
            point3 = st.top() * point3;

            point1.scale();
            point2.scale();
            point3.scale();

            stage << point1;
            stage << point2;
            stage << point3;
            stage << endl;

            noOfTriangles++;
        }
        else if (cmd == "translate")
        {
            double tx, ty, tz;
            scene >> tx >> ty >> tz;
            Matrix matrix = Matrix::translateMatrix(tx, ty, tz);
            matrix = st.top() * matrix;
            st.pop();
            st.push(matrix);
        }
        else if (cmd == "scale")
        {
            double sx, sy, sz;
            scene >> sx >> sy >> sz;
            Matrix matrix = Matrix::scaleMatrix(sx, sy, sz);
            matrix = st.top() * matrix;
            st.pop();
            st.push(matrix);
        }
        else if (cmd == "rotate")
        {
            double rx, ry, rz, angle;
            scene >> angle >> rx >> ry >> rz;
            Matrix matrix = Matrix::rotationMatrix(angle, rx, ry, rz);
            matrix = st.top() * matrix;
            st.pop();
            st.push(matrix);
        }
        else if (cmd == "push")
        {
            st.push(st.top());
        }
        else if (cmd == "pop")
        {
            if (st.size() == 1)
            {
                cout << "Error: Stack is empty" << endl;
                break;
            }
            st.pop();
        }
        else if (cmd == "end")
        {
            break;
        }
        else
        {
            cout << "Error: Invalid Command" << endl;
            break;
        }
    }

    scene.close();
    stage.close();

    // Stage 1 End
    // -----------

    // Stage 2 Start
    // -------------

    scene.open(STAGE1_FILE);
    stage.open(STAGE2_FILE);

    PointVector look(lookX, lookY, lookZ);
    PointVector eye(eyeX, eyeY, eyeZ);
    PointVector up(upX, upY, upZ);

    Matrix viewMatrix = Matrix::identityMatrix();
    viewMatrix = viewMatrix.viewTransformationMatrix(look, eye, up);

    for (int n = 1; n <= noOfTriangles; n++)
    {
        PointVector point1, point2, point3;

        scene >> point1.x >> point1.y >> point1.z;
        scene >> point2.x >> point2.y >> point2.z;
        scene >> point3.x >> point3.y >> point3.z;

        point1 = viewMatrix * point1;
        point2 = viewMatrix * point2;
        point3 = viewMatrix * point3;

        point1.scale();
        point2.scale();
        point3.scale();

        stage << point1;
        stage << point2;
        stage << point3;
        stage << endl;
    }

    scene.close();
    stage.close();

    // Stage 2 End
    // -----------

    // Stage 3 Start
    // -------------

    scene.open(STAGE2_FILE);
    stage.open(STAGE3_FILE);

    Matrix projectMatrix = Matrix::identityMatrix();
    projectMatrix = projectMatrix.projectionMatrix(fovY, aspectRatio, near, far);

    for (int n = 1; n <= noOfTriangles; n++)
    {
        PointVector point1, point2, point3;

        scene >> point1.x >> point1.y >> point1.z;
        scene >> point2.x >> point2.y >> point2.z;
        scene >> point3.x >> point3.y >> point3.z;

        point1 = projectMatrix * point1;
        point2 = projectMatrix * point2;
        point3 = projectMatrix * point3;

        point1.scale();
        point2.scale();
        point3.scale();

        stage << point1;
        stage << point2;
        stage << point3;
        stage << endl;
    }

    scene.close();
    stage.close();

    // Stage 3 End
    // -----------

    return 0;
}
